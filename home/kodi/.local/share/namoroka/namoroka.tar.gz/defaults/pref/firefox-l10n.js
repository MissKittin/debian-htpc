//@line 36 "/llbuild/build/shiretoko-source-3.6.6/mozilla-1.9.2/browser/locales/en-US/firefox-l10n.js"

//@line 38 "/llbuild/build/shiretoko-source-3.6.6/mozilla-1.9.2/browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
