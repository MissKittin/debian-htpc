//@line 2 "/llbuild/build/shiretoko-source-3.6.6/mozilla-1.9.2/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
