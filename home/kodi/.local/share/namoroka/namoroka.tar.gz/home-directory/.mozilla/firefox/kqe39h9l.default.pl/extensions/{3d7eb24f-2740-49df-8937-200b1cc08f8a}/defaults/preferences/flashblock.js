pref("extensions.{3d7eb24f-2740-49df-8937-200b1cc08f8a}.description", "chrome://flashblock/locale/flashblock.properties");
pref("flashblock.enabled",true);
pref("flashblock.whitelist", "");
pref("flashblock.blockLocal",false);
pref("browser.toolbars.showbutton.flashblockMozToggle", false); 